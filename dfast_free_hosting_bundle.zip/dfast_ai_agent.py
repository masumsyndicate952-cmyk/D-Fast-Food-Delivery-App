import os, sqlite3, json, secrets
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, jsonify, session, redirect, url_for, render_template_string, flash

APP=Flask(__name__)
APP.secret_key=os.getenv("DFAST_SECRET_KEY") or secrets.token_hex(32)
DB=os.getenv("DFAST_DB","dfast.db")
ADMIN_USER=os.getenv("DFAST_ADMIN_USER","admin")
ADMIN_PASSWORD=os.getenv("DFAST_ADMIN_PASSWORD")
if not ADMIN_PASSWORD:
    raise RuntimeError("Set DFAST_ADMIN_PASSWORD before starting. Use a long unique password.")

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c
def init():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS restaurants(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT, commission REAL NOT NULL DEFAULT 0.15, active INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS riders(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT, status TEXT NOT NULL DEFAULT 'available', lat REAL, lon REAL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, customer TEXT NOT NULL, phone TEXT, restaurant_id INTEGER, address TEXT NOT NULL, items TEXT NOT NULL DEFAULT '[]', total REAL NOT NULL DEFAULT 0, delivery_fee REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending', rider_id INTEGER, notes TEXT, created TEXT NOT NULL, updated TEXT NOT NULL, FOREIGN KEY(restaurant_id) REFERENCES restaurants(id), FOREIGN KEY(rider_id) REFERENCES riders(id));
        CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, customer TEXT NOT NULL, order_id INTEGER, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', reply TEXT, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_logs(id INTEGER PRIMARY KEY, agent TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL, created TEXT NOT NULL);
        """)
def now(): return datetime.now(timezone.utc).isoformat()
def log(agent,event,detail):
    with db() as c: c.execute("INSERT INTO agent_logs(agent,event,detail,created) VALUES(?,?,?,?)",(agent,event,json.dumps(detail,ensure_ascii=False),now()))
def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get("admin"): return redirect(url_for("login"))
        return f(*a,**k)
    return w
def api_auth():
    return session.get("admin") is True
def require_api():
    if not api_auth(): return jsonify(error="Authentication required"),401
def rowdict(r): return dict(r) if r else None

@APP.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        if request.form.get("username")==ADMIN_USER and secrets.compare_digest(request.form.get("password",""),ADMIN_PASSWORD):
            session.clear(); session["admin"]=True; return redirect("/")
        flash("Invalid credentials")
    return render_template_string(LOGIN)
@APP.get("/logout")
def logout(): session.clear(); return redirect("/login")

@APP.get("/")
@login_required
def home():
    with db() as c:
        stats={t:c.execute(q).fetchone()[0] for t,q in {
        "orders":"SELECT COUNT(*) FROM orders","active":"SELECT COUNT(*) FROM orders WHERE status NOT IN ('delivered','cancelled')",
        "restaurants":"SELECT COUNT(*) FROM restaurants WHERE active=1","riders":"SELECT COUNT(*) FROM riders WHERE status='available'",
        "revenue":"SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'"} .items()}
        orders=c.execute("""SELECT o.*,r.name restaurant,d.name rider FROM orders o LEFT JOIN restaurants r ON r.id=o.restaurant_id LEFT JOIN riders d ON d.id=o.rider_id ORDER BY o.id DESC LIMIT 100""").fetchall()
        restaurants=c.execute("SELECT * FROM restaurants ORDER BY id DESC").fetchall()
        riders=c.execute("SELECT * FROM riders ORDER BY id DESC").fetchall()
        tickets=c.execute("SELECT * FROM tickets ORDER BY id DESC LIMIT 50").fetchall()
        logs=c.execute("SELECT * FROM agent_logs ORDER BY id DESC LIMIT 30").fetchall()
    return render_template_string(DASH,stats=stats,orders=orders,restaurants=restaurants,riders=riders,tickets=tickets,logs=logs)

@APP.post("/restaurants")
@login_required
def add_restaurant():
    n=request.form.get("name","").strip()
    try: fee=float(request.form.get("commission","15"))/100
    except: fee=-1
    if not n or not 0<=fee<=1: flash("Restaurant name and commission (0–100%) required")
    else:
        with db() as c: c.execute("INSERT INTO restaurants(name,phone,commission,created) VALUES(?,?,?,?)",(n,request.form.get("phone"),fee,now()))
        log("restaurant","created",{"name":n}); flash("Restaurant added")
    return redirect("/")
@APP.post("/riders")
@login_required
def add_rider():
    n=request.form.get("name","").strip()
    if not n: flash("Rider name required")
    else:
        with db() as c: c.execute("INSERT INTO riders(name,phone,created) VALUES(?,?,?)",(n,request.form.get("phone"),now()))
        log("delivery","rider_registered",{"name":n}); flash("Rider added")
    return redirect("/")
@APP.post("/orders")
@login_required
def add_order():
    try:
        total=float(request.form.get("total",0)); fee=float(request.form.get("delivery_fee",0)); rid=int(request.form.get("restaurant_id") or 0) or None
        if total<0 or fee<0: raise ValueError()
        customer=request.form.get("customer","").strip(); address=request.form.get("address","").strip()
        if not customer or not address: raise ValueError()
        with db() as c:
            c.execute("INSERT INTO orders(customer,phone,restaurant_id,address,items,total,delivery_fee,status,notes,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (customer,request.form.get("phone"),rid,address,request.form.get("items","[]"),total,fee,"pending",request.form.get("notes"),now(),now()))
            oid=c.execute("SELECT last_insert_rowid()").fetchone()[0]
        log("order","created",{"order_id":oid}); auto_assign(oid); flash(f"Order #{oid} created")
    except Exception: flash("Invalid order details")
    return redirect("/")
def auto_assign(oid):
    with db() as c:
        order=c.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
        rider=c.execute("SELECT * FROM riders WHERE status='available' ORDER BY id LIMIT 1").fetchone()
        if order and rider and order["status"]=="pending":
            c.execute("UPDATE orders SET rider_id=?,status='assigned',updated=? WHERE id=?",(rider["id"],now(),oid))
            c.execute("UPDATE riders SET status='busy' WHERE id=?",(rider["id"],))
            log("delivery","auto_assigned",{"order_id":oid,"rider_id":rider["id"]})
@APP.post("/orders/<int:oid>/status")
@login_required
def order_status(oid):
    status=request.form.get("status")
    allowed={"pending","accepted","preparing","ready","assigned","picked_up","delivered","cancelled"}
    if status not in allowed: flash("Invalid status"); return redirect("/")
    with db() as c:
        o=c.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
        if not o: flash("Order not found"); return redirect("/")
        c.execute("UPDATE orders SET status=?,updated=? WHERE id=?",(status,now(),oid))
        if status in ("delivered","cancelled") and o["rider_id"]: c.execute("UPDATE riders SET status='available' WHERE id=?",(o["rider_id"],))
    log("order","status_changed",{"order_id":oid,"status":status}); return redirect("/")
@APP.post("/orders/<int:oid>/assign")
@login_required
def assign(oid):
    try: rid=int(request.form["rider_id"])
    except: return redirect("/")
    with db() as c:
        r=c.execute("SELECT * FROM riders WHERE id=? AND status='available'",(rid,)).fetchone()
        o=c.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
        if r and o and o["status"] not in ("delivered","cancelled"):
            if o["rider_id"]: c.execute("UPDATE riders SET status='available' WHERE id=?",(o["rider_id"],))
            c.execute("UPDATE orders SET rider_id=?,status='assigned',updated=? WHERE id=?",(rid,now(),oid))
            c.execute("UPDATE riders SET status='busy' WHERE id=?",(rid,))
            log("delivery","manually_assigned",{"order_id":oid,"rider_id":rid})
    return redirect("/")
@APP.post("/tickets")
@login_required
def ticket():
    customer=request.form.get("customer","").strip(); msg=request.form.get("message","").strip()
    if customer and msg:
        with db() as c: c.execute("INSERT INTO tickets(customer,order_id,message,created) VALUES(?,?,?,?)",(customer,request.form.get("order_id") or None,msg,now()))
        log("support","ticket_created",{"customer":customer})
    return redirect("/")
@APP.post("/tickets/<int:tid>/reply")
@login_required
def reply(tid):
    ans=request.form.get("reply","").strip()
    if ans:
        with db() as c: c.execute("UPDATE tickets SET reply=?,status='resolved' WHERE id=?",(ans,tid))
        log("support","ticket_resolved",{"ticket_id":tid})
    return redirect("/")
@APP.get("/api/health")
def health(): return jsonify(status="ok",service="D-FAST Agent System")
@APP.get("/api/orders")
def api_orders():
    if not api_auth(): return require_api()
    with db() as c: return jsonify([dict(r) for r in c.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 500")])
@APP.get("/api/metrics")
def api_metrics():
    if not api_auth(): return require_api()
    with db() as c:
        return jsonify(orders=c.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
        delivered=c.execute("SELECT COUNT(*) FROM orders WHERE status='delivered'").fetchone()[0],
        gross_sales=c.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0],
        delivery_fees=c.execute("SELECT COALESCE(SUM(delivery_fee),0) FROM orders WHERE status='delivered'").fetchone()[0])
@APP.post("/api/agent/dispatch")
def dispatch_api():
    if not api_auth(): return require_api()
    with db() as c: ids=[r[0] for r in c.execute("SELECT id FROM orders WHERE status='pending' ORDER BY id")]
    for oid in ids: auto_assign(oid)
    return jsonify(processed=len(ids))
@APP.get("/export/orders.csv")
@login_required
def export():
    from flask import Response
    import csv,io
    with db() as c: rows=c.execute("SELECT id,customer,phone,restaurant_id,address,total,delivery_fee,status,rider_id,created FROM orders ORDER BY id DESC").fetchall()
    s=io.StringIO(); w=csv.writer(s); w.writerow(rows[0].keys() if rows else ["id","customer","phone","restaurant_id","address","total","delivery_fee","status","rider_id","created"])
    for r in rows:w.writerow(list(r))
    return Response(s.getvalue(),mimetype="text/csv",headers={"Content-Disposition":"attachment; filename=dfast_orders.csv"})

LOGIN="""<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>D-FAST Login</title><style>body{font:16px Arial;background:#eef2f7;display:grid;place-items:center;height:100vh}.box{background:white;padding:30px;border-radius:14px;width:min(340px,85vw);box-shadow:0 5px 30px #ccd}input,button{box-sizing:border-box;width:100%;padding:12px;margin:8px 0;border:1px solid #ccd;border-radius:7px}button{background:#126b46;color:white;font-weight:bold}</style><form class=box method=post><h2>D-FAST Admin</h2>{% with m=get_flashed_messages() %}{% for x in m %}<p>{{x}}</p>{% endfor %}{% endwith %}<input name=username placeholder='Username' required><input type=password name=password placeholder='Password' required><button>Sign in</button></form>"""
DASH=r"""<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1"><title>D-FAST AI Operations</title><style>
*{box-sizing:border-box}body{margin:0;font:14px Arial;background:#f3f6f8;color:#17212b}header{background:#124f3c;color:white;padding:18px 4%;display:flex;justify-content:space-between;align-items:center}main{max-width:1400px;margin:auto;padding:22px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px}.card,.panel{background:white;padding:16px;border-radius:12px;box-shadow:0 2px 10px #1221;margin-bottom:16px}.metric{font-size:25px;font-weight:bold;margin-top:9px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:14px}input,select,textarea,button{font:inherit;padding:9px;border:1px solid #ccd5d9;border-radius:6px;max-width:100%}input,select,textarea{width:100%;margin:4px 0}button,.btn{background:#126b46;color:white;border:0;cursor:pointer;text-decoration:none;padding:9px 12px;border-radius:6px}table{width:100%;border-collapse:collapse;min-width:800px}th,td{text-align:left;padding:9px;border-bottom:1px solid #e7ecee;vertical-align:top}th{background:#f7f9fa}.scroll{overflow:auto}.muted{color:#66747c}.pill{padding:4px 7px;background:#e7f4ed;border-radius:20px;white-space:nowrap}.formrow{display:grid;grid-template-columns:1fr 1fr;gap:8px}h2{margin-top:0}small{color:#66747c}a{color:inherit}@media(max-width:600px){main{padding:12px}header{padding:15px}.formrow{grid-template-columns:1fr}}
</style></head><body><header><div><b>D-FAST</b> <span>AI Operations Dashboard</span></div><a href=/logout>Logout</a></header><main>
{% with m=get_flashed_messages() %}{% for x in m %}<p class=pill>{{x}}</p>{% endfor %}{% endwith %}
<div class=cards>{% for label,val in [('All orders',stats.orders),('In progress',stats.active),('Active restaurants',stats.restaurants),('Available riders',stats.riders),('Delivered sales (SAR)',"%.2f"|format(stats.revenue))] %}<div class=card><div class=muted>{{label}}</div><div class=metric>{{val}}</div></div>{% endfor %}</div>
<div class=grid>
<section class=panel><h2>Register restaurant</h2><form method=post action=/restaurants><input name=name placeholder="Restaurant name" required><input name=phone placeholder="Phone"><label>Commission (%)</label><input name=commission type=number min=0 max=100 step=.1 value=15 required><button>Add restaurant</button></form><hr><h3>Restaurants</h3>{% for r in restaurants %}<p>{{r.name}} <small>{{(r.commission*100)|round(1)}}% · {{'Active' if r.active else 'Inactive'}}</small></p>{% else %}<small>No restaurants yet</small>{% endfor %}</section>
<section class=panel><h2>Register rider</h2><form method=post action=/riders><input name=name placeholder="Rider name" required><input name=phone placeholder="Phone"><button>Add rider</button></form><hr><h3>Riders</h3>{% for r in riders %}<p>{{r.name}} <span class=pill>{{r.status}}</span> <small>{{r.phone or ''}}</small></p>{% else %}<small>No riders yet</small>{% endfor %}</section>
<section class=panel><h2>Create order</h2><form method=post action=/orders><input name=customer placeholder="Customer name" required><input name=phone placeholder="Phone"><select name=restaurant_id><option value="">Restaurant (optional)</option>{% for r in restaurants %}<option value={{r.id}}>{{r.name}}</option>{% endfor %}</select><input name=address placeholder="Delivery address" required><div class=formrow><input name=total type=number min=0 step=.01 placeholder="Food total (SAR)" required><input name=delivery_fee type=number min=0 step=.01 placeholder="Delivery fee (SAR)" value=0></div><textarea name=items placeholder='Items (optional, e.g. [{"name":"Burger","qty":1}])'></textarea><input name=notes placeholder="Notes"><button>Create & auto-dispatch</button></form></section>
<section class=panel><h2>Customer support ticket</h2><form method=post action=/tickets><input name=customer placeholder="Customer name" required><input name=order_id type=number placeholder="Order ID (optional)"><textarea name=message placeholder="Customer issue" required></textarea><button>Create ticket</button></form></section></div>
<section class=panel><h2>Orders <a class=btn href=/export/orders.csv style="float:right">Export CSV</a></h2><div class=scroll><table><tr><th>ID / Customer</th><th>Restaurant</th><th>Address</th><th>Amount</th><th>Rider</th><th>Status / Actions</th></tr>{% for o in orders %}<tr><td>#{{o.id}}<br>{{o.customer}}<br><small>{{o.phone or ''}}</small></td><td>{{o.restaurant or '—'}}</td><td>{{o.address}}</td><td>SAR {{'%.2f'|format(o.total)}}<br><small>Delivery {{'%.2f'|format(o.delivery_fee)}}</small></td><td>{{o.rider or 'Unassigned'}}{% if o.status not in ['delivered','cancelled'] %}<form method=post action="/orders/{{o.id}}/assign"><select name=rider_id required><option value="">Assign available rider</option>{% for r in riders if r.status=='available' %}<option value={{r.id}}>{{r.name}}</option>{% endfor %}</select><button>Assign</button></form>{% endif %}</td><td><span class=pill>{{o.status}}</span><form method=post action="/orders/{{o.id}}/status"><select name=status>{% for s in ['pending','accepted','preparing','ready','assigned','picked_up','delivered','cancelled'] %}<option value={{s}} {% if o.status==s %}selected{% endif %}>{{s}}</option>{% endfor %}</select><button>Update</button></form></td></tr>{% else %}<tr><td colspan=6>No orders</td></tr>{% endfor %}</table></div></section>
<section class=panel><h2>Support tickets</h2><div class=scroll><table><tr><th>ID</th><th>Customer / Order</th><th>Message</th><th>Status / Reply</th></tr>{% for t in tickets %}<tr><td>{{t.id}}</td><td>{{t.customer}}<br>#{{t.order_id or '—'}}</td><td>{{t.message}}</td><td>{{t.status}}{% if t.status=='open' %}<form method=post action="/tickets/{{t.id}}/reply"><textarea name=reply placeholder="Reply / resolution" required></textarea><button>Resolve</button></form>{% else %}<small>{{t.reply}}</small>{% endif %}</td></tr>{% else %}<tr><td colspan=4>No tickets</td></tr>{% endfor %}</table></div></section>
<section class=panel><h2>AI Agent activity log</h2><p class=muted>Rule-based automation events: order creation, rider dispatch, support and status updates.</p>{% for l in logs %}<p><b>{{l.agent}} / {{l.event}}</b> <small>{{l.created}}</small><br><code>{{l.detail}}</code></p>{% else %}<small>No activity yet</small>{% endfor %}</section>
<p class=muted>API health: <a href=/api/health>/api/health</a> · Metrics API: <a href=/api/metrics>/api/metrics</a>. Protect this dashboard behind HTTPS before public deployment.</p></main></body></html>"""
init()

if __name__=="__main__":
    APP.run(host=os.getenv("HOST","127.0.0.1"),port=int(os.getenv("PORT","8000")),debug=False)
